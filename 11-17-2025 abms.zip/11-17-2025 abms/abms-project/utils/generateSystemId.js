export const generateSystemId = () => {
  return 'SYS-' + Date.now();
};
