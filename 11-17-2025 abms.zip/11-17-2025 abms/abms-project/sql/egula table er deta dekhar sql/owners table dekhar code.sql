use abms;
select * from owners;