use abms;
select * from permissions_catalog;