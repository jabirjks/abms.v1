CREATE TABLE IF NOT EXISTS permissions_catalog (
    name VARCHAR(100) PRIMARY KEY,
    description TEXT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;