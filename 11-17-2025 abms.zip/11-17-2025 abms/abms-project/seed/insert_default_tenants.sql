-- ✅ Default Tenant ইনসার্ট
INSERT IGNORE INTO tenants (name) VALUES ('Default Tenant');
